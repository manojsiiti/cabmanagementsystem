package parkingsystem.entities;

public enum State {
    Full, Empty
}
