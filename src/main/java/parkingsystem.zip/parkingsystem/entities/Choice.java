package parkingsystem.entities;

public enum Choice {
    Near_Exit, Near_Entry
}
