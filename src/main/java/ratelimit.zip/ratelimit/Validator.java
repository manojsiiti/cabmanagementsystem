package ratelimit;

public class Validator {

}
