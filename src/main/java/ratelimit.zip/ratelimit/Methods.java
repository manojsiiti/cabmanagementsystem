package ratelimit;

public class Methods {

private GetLimit GET = new GetLimit();
private PostLimit POST = new PostLimit();

public GetLimit getGET() {
return GET;
}

public void setGET(GetLimit gET) {
this.GET = gET;
}

public PostLimit getPOST() {
return POST;
}

public void setPOST(PostLimit pOST) {
this.POST = pOST;
}

}