package ratelimit;

public enum RequestType {
    GET, POST
}
